## ProxyScraper
 
## Check live proxies
```
curl -s "https://raw.githubusercontent.com/gitrecon1455/ProxyScraper/refs/heads/main/proxies.txt" | python3 checker.py --url "https://google.com" --timeout 1 --threads 100
```